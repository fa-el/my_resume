from kivy.app import App
from kivy.uix.screenmanager import Screen, SlideTransition


class Bantuan(Screen):
    def disconnect(self):
        app = App.get_running_app()

        self.manager.transition = SlideTransition(direction="right")
        self.manager.current = 'main'

        app.config.read(app.get_application_config())
        app.config.write()

    def refresh(self):
        self.ids.sm3.current = 'help_menu'

class Bantuan1(Screen):
    def back(self):
        app = App.get_running_app()

        self.manager.transition = SlideTransition(direction="left")
        self.manager.current = 'main'

        app.config.read(app.get_application_config())
        app.config.write()

class Bantuan2(Screen):
    def back(self):
        app = App.get_running_app()

        self.manager.transition = SlideTransition(direction="left")
        self.manager.current = 'main'

        app.config.read(app.get_application_config())
        app.config.write()

class Bantuan3(Screen):
    def back(self):
        app = App.get_running_app()

        self.manager.transition = SlideTransition(direction="left")
        self.manager.current = 'main'

        app.config.read(app.get_application_config())
        app.config.write()
from kivy.app import App
from kivy.uix.screenmanager import Screen, SlideTransition

class Login(Screen):
    def adminScreen(self):
        app = App.get_running_app()

        self.manager.transition = SlideTransition(direction="left")
        self.manager.current = 'adlogin'

        app.config.read(app.get_application_config())
        app.config.write()

    def do_login(self):
        app = App.get_running_app()

        username_input = self.ids.usrname
        username_text = username_input.text
        password_input = self.ids.passwd
        password_text = password_input.text

        self.manager.transition = SlideTransition(direction="left")
        self.manager.current = 'main'

        app.config.read(app.get_application_config())
        app.config.write()

    def do_signup(self):
        app = App.get_running_app()

        self.manager.transition = SlideTransition(direction="left")
        self.manager.current = 'signup'
        self.manager.get_screen('signup').resetForm()

        app.config.read(app.get_application_config())
        app.config.write()

    def resetForm(self):
        self.ids['usrname'].text = ""
        self.ids['passwd'].text = ""
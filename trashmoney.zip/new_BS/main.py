from kivy.app import App
from kivy.properties import StringProperty
from kivy.uix.screenmanager import ScreenManager, Screen, SlideTransition
from kivymd.theming import ThemeManager

from login import Login
from pendaftaran import Register
from userHelp import Bantuan
from userHelp import Bantuan1
from userHelp import Bantuan2
from userHelp import Bantuan3
from userHome import MainMenu
from userOrder import Order
from userProfile import Profile
from userSaldo import Saldo

class Connectivity(Screen):
    def userConnected(self):
        pass
    def adminConnected(self):
        pass

class AdminLogin(Screen):
    def admin_login(self):
        app = App.get_running_app()

        adminName_input = self.ids.adminName
        username_text = adminName_input.text
        password_input = self.ids.passwd
        password_text = password_input.text

        self.manager.transition = SlideTransition(direction="left")
        self.manager.current = 'admain'

        app.config.read(app.get_application_config())
        app.config.write()

    def resetForm(self):
        self.ids['adminName'].text = ""
        self.ids['passwd'].text = ""

class AdminMain(Screen):
    def take_order(self):
        pass
    def nasabah(self):
        pass
    def admin_profil(self):
        pass
    def disconnect(self):
        self.manager.transition = SlideTransition(direction="right")
        self.manager.current = 'adlogin'
        self.manager.get_screen('adlogin').resetForm()

class BankSampahApp(App):
    username = StringProperty(None)
    password = StringProperty(None)

    theme_cls = ThemeManager()
    def build(self):
        manager = ScreenManager()

        manager.add_widget(Login(name='login'))
        manager.add_widget(AdminLogin(name='adlogin'))
        manager.add_widget(AdminMain(name='admain'))
        manager.add_widget(Register(name='signup'))
        manager.add_widget(MainMenu(name='main'))
        manager.add_widget(Order(name='order'))
        manager.add_widget(Saldo(name='saldo'))
        manager.add_widget(Profile(name='profile'))
        manager.add_widget(Bantuan(name='help'))
        manager.add_widget(Bantuan1(name='b1'))
        manager.add_widget(Bantuan2(name='b2'))
        manager.add_widget(Bantuan3(name='b3'))


        return manager

if __name__ == '__main__':
    BankSampahApp().run()

from kivy.app import App
from kivy.uix.screenmanager import Screen, SlideTransition


class Register(Screen):
    def success(self):
        app = App.get_running_app()

        nama_input = self.ids.nama
        namaText = nama_input.text
        username_input = self.ids.usrname
        usernameText = username_input
        passwd_input = self.ids.passwd
        passwdText = passwd_input
        phone_input = self.ids.phone
        phoneText = phone_input

        self.manager.transition = SlideTransition(direction="left")
        self.manager.current = 'main'

        app.config.read(app.get_application_config())
        app.config.write()

    def resetForm(self):
        self.ids.nama.text = ''
        self.ids.usrname.text = ''
        self.ids.passwd.text = ''
        self.ids.phone.text = ''

    def disconnect(self):
        self.manager.transition = SlideTransition(direction="right")
        self.manager.current = 'login'
        self.manager.get_screen('login').resetForm()
from kivy.app import App
from kivy.uix.screenmanager import Screen, SlideTransition


class Saldo(Screen):
    def disconnect(self):
        app = App.get_running_app()

        self.manager.transition = SlideTransition(direction="right")
        self.manager.current = 'main'

        app.config.read(app.get_application_config())
        app.config.write()
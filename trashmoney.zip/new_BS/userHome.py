from kivy.app import App
from kivy.uix.screenmanager import Screen, SlideTransition
from kivymd.navigationdrawer import NavigationLayout


class MainMenu(Screen):
    def disconnect(self):

        self.manager.transition = SlideTransition(direction="right")
        self.manager.current = 'login'
        self.manager.get_screen('login').resetForm()

    def do_order(self):
        app = App.get_running_app()
        self.manager.transition = SlideTransition(direction="left")
        self.manager.current = 'order'
        self.manager.get_screen('order').refresh()

        app.config.read(app.get_application_config())
        app.config.write()

    def go_b1(self):
        app = App.get_running_app()

        self.manager.transition = SlideTransition(direction="left")
        self.manager.current = 'b1'

        app.config.read(app.get_application_config())
        app.config.write()

    def go_b2(self):
        app = App.get_running_app()

        self.manager.transition = SlideTransition(direction="left")
        self.manager.current = 'b2'

        app.config.read(app.get_application_config())
        app.config.write()

    def go_b3(self):
        app = App.get_running_app()

        self.manager.transition = SlideTransition(direction="left")
        self.manager.current = 'b3'

        app.config.read(app.get_application_config())
        app.config.write()

    def do_saldo(self):
        app = App.get_running_app()
        app.config.read(app.get_application_config())
        app.config.write()
        self.manager.transition = SlideTransition(direction="left")
        self.manager.current = 'saldo'

    def do_profil(self):
        app = App.get_running_app()
        app.config.read(app.get_application_config())
        app.config.write()
        self.manager.transition = SlideTransition(direction="left")
        self.manager.current = 'profile'
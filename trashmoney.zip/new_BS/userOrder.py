from kivy.app import App
from kivy.uix.screenmanager import Screen, SlideTransition


class Order(Screen):
    def disconnect(self):
        app = App.get_running_app()

        self.manager.transition = SlideTransition(direction="right")
        self.manager.current = 'main'

        app.config.read(app.get_application_config())
        app.config.write()

    def refresh(self):
        self.ids.sm.current = 'add_address'
        self.ids.address.text = ''